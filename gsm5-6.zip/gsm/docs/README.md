# ExploitGSM
Exploit for 6.4 - 6.5 kernels and another exploit for 5.15 - 6.5

Телеграм для зв'язку -> https://t.me/YuriiCrimson  <br />
Телеграм чат -> https://t.me/itcrowdua  <br />

Зимой я знайшов дві вразливості в n_gsm драйвері. Після цього мені написав Jammes з пропозицією купити їх в мене.
Як ви зрозуміли він мене обдурив. Але я ще не знав що перший експлоїт для 6.4 та 6.5 був злитий. Тому я три дні назад злив його не знаючи того що він був злитий.
А в твітері я побачив вот це https://jmpeax.dev/The-tale-of-a-GSM-Kernel-LPE.html. Цей виблядок вкрав в мене мій труд та ще видав за свій. 
Тут ви можете побачити https://t.me/itcrowdua/1/203010 відео нашої переписки як доказ того що я не брешу.
І тепер я злив ще один експлоїт який затрагує 5.15 версії до 6.5 далі драйвер можна використати тільки з CAP_NET_ADMIN правами.
Щоб випередити ту мразоту.

Перший експлоїт 5.15 до 6.5
Результат  <br />
![alt text](debian12.png)
Debian 12 6.1 kernel Dekstop <br />

Експлоїт не працює на всіх ядрах, наприклад на убунту. Але на Debian і Fedora 
працює.

Другий експлоїт 6.4 до 6.5
Результат  <br />
![alt text](result.png)

Ubuntu 22.04 6.5 kernel Dekstop <br />

# Compile
```bash
sudo apt-get install libcap-dev
#if not already installed

mkdir build

cd build

cmake ../ExploitGSM

cmake --build .
```

ExploitGSM_5_15_to_6_1 перший експлоїт <br />
ExploitGSM_6_5 - другий експлоїт. <br />
OffsetGenerator - генератор оффсетів. <br /> 
writeup.docx - чтиво як працює експлоїт.  <br />




